import requests
import random
import time
import string
import os
import uuid
import subprocess
import re
from faker import Faker

fake = Faker()

CARD_PREFIXES = {
    'Visa': ['4'],
    'Mastercard': ['5', '2'],
    'American Express': ['34', '37'],
    'Discover': ['6011', '65'],
    'JCB': ['35'],
    'Diners Club': ['30', '36', '38'],
    'UnionPay': ['62'],
    'Maestro': ['50', '56', '57', '58', '67']
}

ANIME_CACHE = []

def scrape_pinterest_videos(max_pins=5):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
    video_urls = set()
    queries = ['anime video aesthetic', 'anime edit amv', 'anime music video']

    for query in queries:
        try:
            q = query.replace(' ', '+')
            r = requests.get(f'https://www.pinterest.com/search/pins/?q={q}', headers=headers, timeout=15)
            pin_ids = set(re.findall(r'/pin/(\d{10,})/', r.text))
            for pid in list(pin_ids)[:max_pins]:
                try:
                    pr = requests.get(f'https://www.pinterest.com/pin/{pid}/', headers=headers, timeout=15)
                    urls = re.findall(r'https?://v\d\.pinimg\.com/videos/[^"\'<>]+\.mp4', pr.text)
                    for u in urls:
                        if '720w' in u or '720p' in u or '1080p' in u:
                            video_urls.add(u)
                            if len(video_urls) >= max_pins:
                                break
                except:
                    pass
                if len(video_urls) >= max_pins:
                    break
            if len(video_urls) >= max_pins:
                break
        except:
            pass
    return list(video_urls)

def preload_anime():
    video_urls = scrape_pinterest_videos()
    if len(video_urls) < 2:
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page()
                page.goto('https://www.pinterest.com/search/pins/?q=anime+video', timeout=30000)
                page.wait_for_timeout(3000)
                content = page.content()
                urls = re.findall(r'https?://v\d\.pinimg\.com/videos/[^"\'<>]+\.mp4', content)
                for u in urls:
                    if ('720w' in u or '720p' in u) and u not in video_urls:
                        video_urls.append(u)
                browser.close()
        except:
            video_urls = [
                'https://v1.pinimg.com/videos/iht/expMp4/96/39/7e/96397e9e74e9696f8c25159c033ce555_720w.mp4',
                'https://v1.pinimg.com/videos/iht/720p/8f/cc/0a/8fcc0a68064a347e05b25804906a1590.mp4',
                'https://v1.pinimg.com/videos/iht/expMp4/83/08/c5/8308c505b69c0720b2fbbaca23b5c48d_720w.mp4',
                'https://v1.pinimg.com/videos/iht/expMp4/86/20/07/862007434e83223a5d727bf3094b3fd3_720w.mp4',
                'https://v1.pinimg.com/videos/iht/expMp4/32/0c/45/320c45a4c4cf46f6c42b82c17384d052_720w.mp4',
                'https://v1.pinimg.com/videos/iht/av1Mp4-control-v2/c6/fc/ae/c6fcae4e803d5082b57434c9759eec37_360w.mp4',
                'https://v1.pinimg.com/videos/iht/expMp4/60/9a/77/609a77b683361953c7d2611c2d7258f5_720w.mp4',
            ]
    for url in video_urls[:7]:
        try:
            path = f"/tmp/ac_raw_{uuid.uuid4().hex}.mp4"
            resp = requests.get(url, timeout=15)
            if resp.status_code == 200:
                with open(path, 'wb') as f:
                    f.write(resp.content)
                out = f"/tmp/ac_169_{uuid.uuid4().hex}.mp4"
                try:
                    subprocess.run(['ffmpeg', '-i', path, '-vf', 'scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2', '-c:a', 'copy', '-y', '-loglevel', 'error', out], check=True, capture_output=True, timeout=30)
                    if os.path.exists(out) and os.path.getsize(out) > 0:
                        os.remove(path)
                        ANIME_CACHE.append(out)
                        print(f"📥 Cached video")
                except:
                    try: os.remove(path)
                    except: pass
        except:
            pass
    print(f"📦 Preloaded {len(ANIME_CACHE)} anime videos")

def luhn_checksum(num):
    digits = [int(d) for d in num]
    for i in range(len(digits) - 1, -1, -2):
        digits[i] *= 2
        if digits[i] > 9:
            digits[i] -= 9
    return sum(digits) % 10

def generate_card_number(card_type):
    if card_type not in CARD_PREFIXES:
        card_type = random.choice(list(CARD_PREFIXES.keys()))
    prefix = random.choice(CARD_PREFIXES[card_type])
    if card_type == 'American Express':
        length = 15
    elif card_type == 'Diners Club':
        length = 14
    else:
        length = 16
    body = prefix + ''.join([str(random.randint(0, 9)) for _ in range(length - len(prefix) - 1)])
    csum = luhn_checksum(body + '0')
    check_digit = (10 - csum) % 10
    return body + str(check_digit), card_type

def luhn_algorithm(card_number):
    return luhn_checksum(card_number) == 0

def generate_card_details():
    card_number, card_type = generate_card_number(random.choice(list(CARD_PREFIXES.keys())))
    month = str(random.randint(1, 12)).zfill(2)
    year = str(random.randint(25, 32)).zfill(2)
    if card_type == 'American Express':
        cvv = str(random.randint(1000, 9999)).zfill(4)
    else:
        cvv = str(random.randint(100, 999)).zfill(3)
    return f"{card_number}|{month}|{year}|{cvv}", card_type

def delete_old_messages():
    try:
        bot_token = 'yout token'
        chat_id = -chatid
        api = f'https://api.telegram.org/bot{bot_token}'
        r = requests.get(f'{api}/getUpdates', timeout=10)
        data = r.json()
        if data.get('ok'):
            msg_ids = set()
            for update in data['result']:
                if 'channel_post' in update:
                    msg_ids.add(update['channel_post']['message_id'])
            for mid in sorted(msg_ids)[:-10]:
                try:
                    requests.post(f'{api}/deleteMessage', json={'chat_id': chat_id, 'message_id': mid}, timeout=5)
                except:
                    pass
            print(f"🗑️ Cleaned {len(msg_ids) - min(10, len(msg_ids))} old messages")
    except:
        pass

def send_messages():
    bot_token = 'your token'
    chat_id = -your chat id
    telegram_api = f'https://api.telegram.org/bot{bot_token}'
    preload_anime()
    delete_old_messages()
    max_retries = 2
    anime_idx = 0
    card_count = 0

    while True:
        card_count += 1
        card_details, card_type = generate_card_details()
        card_number = card_details.split('|')[0]
        if not luhn_algorithm(card_number):
            continue
        BIN = card_number[:6]
        try:
            response = requests.get(f"https://bins.antipublic.cc/bins/{BIN}", timeout=5)
            if response.status_code == 200 and response.json().get('brand'):
                req = response.json()
                brand = req.get('brand', card_type).upper()
                country = req.get('country', 'US')
                country_name = req.get('country_name', 'United States')
                country_flag = req.get('country_flag', '🇺🇸')
                bank = req.get('bank', 'Unknown Bank')
                level = req.get('level', 'Standard')
                typea = req.get('type', 'Credit')
            else:
                brand, country, country_name, country_flag, bank, level, typea = card_type, "US", "United States", "🇺🇸", "Unknown Bank", "Standard", "Credit"
        except:
            brand, country, country_name, country_flag, bank, level, typea = card_type, "US", "United States", "🇺🇸", "Unknown Bank", "Standard", "Credit"
        month, year, cvv = card_details.split('|')[1], card_details.split('|')[2], card_details.split('|')[3]
        full_name = fake.name()

        msg = (
            f"\n Cᴏᴅᴇx Sᴄʀᴀᴘᴘᴇʀ! \n"
            f"━━━━━━━━━━━━━━\n"
            f"<b>⌖ 𝗖𝗰 ⤳</b> <code>{card_details}</code>\n"
            f"⌖ 𝗦𝘁𝗮𝘁𝘂𝘀 ⤳ 𝘼𝙋𝙋𝙍𝙊𝙑𝙀𝘿! ✅\n"
            f"⌖ 𝗕𝗶𝗻 ⤳ {BIN}\n"
            f"━━━━━━━━━━━━━━\n"
            f"<b>⌮ 𝗜𝗻𝗳𝗼 ⤳ </b>  <code>{brand}-{typea}-{level}</code>\n"
            f"<b>⌮ 𝘽𝘼𝙉𝙆 ⤳ </b>  <code>{bank}</code>\n"
            f"<b>⌮ 𝘾𝙊𝙐𝙉𝙏𝙍𝙔 ⤳ </b>  <code>{country_name} [{country_flag}]</code>\n"
            f"━━━━━━━━━━━━━━\n"
            f"<b>⌮ 𝐄𝐗𝐓𝐑𝐀 𝐁𝐈𝐍 ⤳ </b>  <code>{card_number[:6]}xxxx|{month}|{year}|rnd</code>\n"
            f"<b>⌮ 𝗡𝗮𝗺𝗲 ⤳ </b>  <code>{full_name}</code>\n"
            f"━━━━━━━━━━━━━━\n"
            f"<b>⌮ 𝗠𝗼𝗱𝗲 𝗕𝘆 ⤳ </b>  <a href='https://t.me/codex_update'>@codex_update</a>\n"
            f"━━━━━━━━━━━━━━\n"
        )

        retry_count, message_sent = 0, False
        while retry_count < max_retries and not message_sent:
            try:
                if ANIME_CACHE:
                    anime_idx = (anime_idx + 1) % len(ANIME_CACHE)
                    media_file = ANIME_CACHE[anime_idx]
                    with open(media_file, 'rb') as f:
                        files = {'video': f}
                        data = {
                            'chat_id': chat_id, 'caption': msg, 'parse_mode': 'HTML',
                            'width': 1280, 'height': 720, 'supports_streaming': True
                        }
                        response = requests.post(f'{telegram_api}/sendVideo', files=files, data=data, timeout=60)
                else:
                    with open("attached_assets/IMG_20250709_153403_228_1752056794715.jpg", 'rb') as photo:
                        files = {'photo': photo}
                        data = {'chat_id': chat_id, 'caption': msg, 'parse_mode': 'HTML'}
                        response = requests.post(f'{telegram_api}/sendPhoto', files=files, data=data, timeout=60)

                if response.status_code == 200:
                    print(f"✅ Sent card {card_count}: {card_type} - {card_details}")
                    message_sent = True
                elif response.status_code == 429:
                    retry_after = response.json().get('parameters', {}).get('retry_after', 5)
                    time.sleep(retry_after)
                    retry_count += 1
                else:
                    print(f"❌ Error: {response.text[:150]}")
                    retry_count += 1; time.sleep(1)
            except Exception as e:
                print(f"❌ Error: {e}")
                retry_count += 1; time.sleep(1)

        if not message_sent:
            print(f"❌ Failed card {card_count} after {max_retries} attempts")
        time.sleep(2)

if __name__ == '__main__':
    send_messages()
